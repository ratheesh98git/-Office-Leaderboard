from flask import Flask, render_template, request
import requests
import pandas as pd
import datetime as dt

app = Flask(__name__, static_url_path='/static')

check = [""]
cleaning = []

cleaning_members_avatar_mapping = {}
}
check_members_avatar_mapping = {}
}

def customsort(df):
    df_less_than_1 = df[df['ratio'] < 1.0].sort_values(by=['handle_pic_number'], ascending = [False])
    df_more_than_1 = df[(df['ratio'] >= 1.0)&(df['ratio'] <= 5.0)].sort_values(by=['handle_pic_number'], ascending = [False])
    result_df = pd.concat([df_less_than_1, df_more_than_1])
    return result_df

@app.route("/", methods=['GET', 'POST'])

def ind():
    if request.method == 'POST':
        return fu()
    return render_template("index.html")

@app.route("/leaderboard.html", methods=['GET', 'POST'])

def fu():       
    if request.method == 'POST':
        fromtime = request.form['fromtime']
        totime = request.form['totime']
        url = ""
        file = requests.get(url)
        js = file.json()
        alldata = js['data']['data_list']
        if file:
            df = pd.DataFrame(alldata)

            grouped_df = df.groupby('user_name').agg({'error_number': 'sum', 'handle_pic_number': 'sum'}).reset_index()
            grouped_df['ratio'] = (grouped_df['error_number'] / grouped_df['handle_pic_number'])*100
           
            cleaning_data = grouped_df[grouped_df["user_name"].isin(cleaning)]
            check_data = grouped_df[grouped_df["user_name"].isin(check)]

            cleaning_data = cleaning_data.sort_values(by="ratio", ascending=True)
            check_data = check_data.sort_values(by="ratio", ascending=True)
            
            cleaning_data=customsort(cleaning_data)
            check_data=customsort(check_data)

            time = dt.datetime.now().strftime("%I:%M %p")
            
            cleaning_data['image_path'] = '/static/Avatar/clean/'+cleaning_data['user_name'].map(cleaning_members_avatar_mapping)
            check_data['image_path'] = '/static/Avatar/check/'+check_data['user_name'].map(check_members_avatar_mapping)

            return render_template("leaderboard.html", time=time, cleaning_data=cleaning_data.iloc[:10], check_data=check_data.iloc[:10])
    return render_template("leaderboard.html", time="", cleaning_data=pd.DataFrame(), check_data=pd.DataFrame())

if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=int(4000))